/*
James Dotson
  /\_/\
=( °w° )=
  )   (  //
 (__ __)//
CODE CAT APPROVED!
*/
package com.example.james.icantcount;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity
{
    Button count, res, incDec;
    int currentCount = 0;
    String str;
    Boolean inDe = false;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //mein code
        count = (Button) findViewById(R.id.counterButton);
        res = (Button) findViewById(R.id.resetButton);
        incDec = (Button) findViewById(R.id.inc_dec);

        count.setOnClickListener(bCount);
        res.setOnClickListener(bRes);
        incDec.setOnClickListener(bIncDec);
    }

        Button.OnClickListener bIncDec = new Button.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                //increment/decrement selection
                if (inDe == true)
                {
                    inDe = false;
                    incDec.setText("DECREMENT");
                }
                else if (inDe == false)
                {
                    inDe = true;
                    incDec.setText("INCREMENT");
                }
            }
        };

        Button.OnClickListener bCount = new Button.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                //if statement for increment/decrement
                if (inDe == true)
                {
                    //decrementing
                    currentCount--;
                    //setting text on counter button
                    str = Integer.toString(currentCount);
                    count.setText(str + "\n(-)");
                }
                else if(inDe == false)
                {
                    //incrementing
                    currentCount++;
                    //setting text on counter button
                    str = Integer.toString(currentCount);
                    count.setText(str + "\n(+)");
                }

            }
        };

        Button.OnClickListener bRes = new Button.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                //reseting count, setting to increment
                currentCount = 0;
                count.setText("TAP TO START COUNTING");
                incDec.setText("DECREMENT");
                inDe = false;
            }
        };
}
